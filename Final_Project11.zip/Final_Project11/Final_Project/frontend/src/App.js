// frontend/src/App.js
/*
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import AdminDashboard from './components/AdminDashboard';

const App = () => {
  return (
      <Router>
          <Routes>
              <Route  path="/" element={<LoginPage />} />
              <Route path="/dashboard" element={<AdminDashboard/>} />
          </Routes>
      </Router>
  );
};

*/


//import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './components/LoginPage'
import AdminDashboard from './components/AdminDashboard'
function App() {


    return (
        <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/admin" element={<AdminDashboard />} />
        </Routes>
    )
}
export default App;
